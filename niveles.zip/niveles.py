# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 José Castro Basso (FADU–UDELAR) — idea and first version.
# Copyright (C) 2026 Marco Sumari Tellez and IngeTrazo contributors.
"""Niveles — building levels as an IngeTrazo EXTENSION.

Levels (PB, PA, Azotea…) with their height; in an elevation or a section
seen in parallel projection, a dashed guide across the drawing at each
level, and the cursor snaps to those heights — «Nivel PA» on the tip.

José Castro Basso wrote the first version for teaching architectural
representation at FADU–UDELAR (Montevideo). It is an extension and not part
of IngeTrazo on purpose: the core stays for everyone, and what a course or
an office needs is installed by whoever needs it — and can be maintained
by them. It is also the worked example of the extension API
(docs/plugins.md): document data, a side panel, a viewport overlay and an
inference, all through `setup(app)`.

Install: copy this file into the plugins folder (Extensions ▸ Open plugins
folder) and restart IngeTrazo. The «Niveles» tab appears in the side tray.
"""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QColor, QFont, QPen, QVector3D
from PySide6.QtWidgets import (
    QCheckBox, QDialog, QDialogButtonBox, QDoubleSpinBox, QFormLayout,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QMessageBox, QPushButton, QVBoxLayout, QWidget,
)

from core.i18n import current_language
from core.section import SectionPlane

#: Guides and snapping only when the view looks sideways: |pitch| below this.
MAX_PITCH_DEG = 15.0
COLOR = (0.95, 0.45, 0.16)                    # IngeTrazo's accent

# An extension brings its own words — the core catalogues stay the core's.
_TEXTS = {
    "es": {"Levels": "Niveles", "Level guides": "Guías de nivel",
           "Add": "Añadir", "Edit": "Editar", "Delete": "Eliminar",
           "Name:": "Nombre:", "Height:": "Altura:", "New level": "Nuevo nivel",
           "Edit level": "Editar nivel", "Level {n}": "Nivel {n}",
           "Show elevation": "Ver alzado", "Create floor plans": "Crear plantas",
           "Front view in parallel projection, where the level guides show.":
           "Vista frontal en proyección paralela, donde se ven las guías de "
           "nivel.",
           "Double-click a level to edit it. The guides show in elevations "
           "and sections in parallel projection.":
           "Doble clic en un nivel para editarlo. Las guías se ven en alzados "
           "y cortes en proyección paralela."},
    "pt-BR": {"Levels": "Níveis", "Level guides": "Guias de nível",
              "Add": "Adicionar", "Edit": "Editar", "Delete": "Excluir",
              "Name:": "Nome:", "Height:": "Altura:", "New level": "Novo nível",
              "Edit level": "Editar nível", "Level {n}": "Nível {n}",
              "Show elevation": "Ver elevação", "Create floor plans": "Criar plantas",
              "Front view in parallel projection, where the level guides show.":
              "Vista frontal em projeção paralela, onde as guias de nível "
              "aparecem.",
              "Double-click a level to edit it. The guides show in elevations "
              "and sections in parallel projection.":
              "Clique duas vezes num nível para editá-lo. As guias aparecem "
              "em elevações e cortes em projeção paralela."},
}


def _t(text: str, **kw) -> str:
    out = _TEXTS.get(current_language(), {}).get(text, text)
    return out.format(**kw) if kw else out


# ---- The data (the document's, through the API) --------------------------------

def _state(app) -> dict:
    """`{"levels": [{"name", "z"}...], "guides": bool} — what the
    document holds, sorted by height."""
    raw = app.document_data({}) or {}
    levels = []
    for lv in raw.get("levels", []) if isinstance(raw, dict) else []:
        try:
            levels.append({"name": str(lv["name"]), "z": float(lv["z"])})
        except (KeyError, TypeError, ValueError):
            continue
    levels.sort(key=lambda lv: lv["z"])
    return {"levels": levels, "guides": bool(raw.get("guides", True))
            if isinstance(raw, dict) else True}


def _sideways(viewport) -> bool:
    """An elevation or section in parallel projection — where heights read."""
    cam = viewport.camera
    if getattr(cam, "perspective", True):
        return False
    return abs(math.degrees(getattr(cam, "pitch", 0.0))) <= MAX_PITCH_DEG


def _fmt(z: float) -> str:
    return f"{z:+.2f}".replace("+0.00", "±0.00")


# ---- Panel ------------------------------------------------------------------------

class _LevelDialog(QDialog):
    def __init__(self, parent, title: str, name: str, z: float) -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        form = QFormLayout(self)
        self.name = QLineEdit(name)
        form.addRow(_t("Name:"), self.name)
        self.z = QDoubleSpinBox()
        self.z.setRange(-1000.0, 1000.0)
        self.z.setDecimals(2)
        self.z.setSingleStep(0.10)
        self.z.setSuffix(" m")
        self.z.setValue(z)
        form.addRow(_t("Height:"), self.z)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)


class LevelsPanel(QWidget):
    def __init__(self, app) -> None:
        super().__init__()
        self.app = app
        lay = QVBoxLayout(self)
        self.guides = QCheckBox(_t("Level guides"))
        self.guides.toggled.connect(self._on_guides)
        lay.addWidget(self.guides)
        self.list = QListWidget()
        self.list.itemDoubleClicked.connect(lambda _i: self._edit())
        lay.addWidget(self.list, 1)
        row = QHBoxLayout()
        for text, slot in ((_t("Add"), self._add), (_t("Edit"), self._edit),
                           (_t("Delete"), self._delete)):
            b = QPushButton(text)
            b.clicked.connect(slot)
            row.addWidget(b)
        lay.addLayout(row)
        
        # The guides only exist in a parallel elevation — which is exactly
        # where nobody starts. One click gets there (Marco's first try, 25-09:
        # «hice niveles pero no veo nada en el dibujo» — he was in perspective).
        elev = QPushButton(_t("Show elevation"))
        elev.setToolTip(_t("Front view in parallel projection, where the "
                           "level guides show."))
        elev.clicked.connect(self._show_elevation)
        lay.addWidget(elev)

        # Botón para crear plantas
        self.btn_plantas = QPushButton(_t("Create floor plans"))
        self.btn_plantas.clicked.connect(self._crear_plantas)
        lay.addWidget(self.btn_plantas)

        hint = QLabel(_t("Double-click a level to edit it. The guides show in "
                         "elevations and sections in parallel projection."))
        hint.setWordWrap(True)
        lay.addWidget(hint)
        self.refresh()

    def _show_elevation(self) -> None:
        vp = self.app.viewport
        vp.camera.set_view("front")
        vp.camera.perspective = False
        vp.update()

    def _crear_plantas(self) -> None:
        st = _state(self.app)
        levels = st["levels"]

        if not levels:
            QMessageBox.information(
                self,
                _t("Levels"),
                "No hay niveles definidos para crear plantas."
            )
            return

        from core.saved_views import SavedView

        scene = self.app.viewport.scene
        camera = self.app.viewport.camera

        # Guardar estado actual de la cámara
        orig_perspective = camera.perspective
        orig_target = QVector3D(camera.target)
        orig_yaw = camera.yaw
        orig_pitch = camera.pitch
        orig_roll = getattr(camera, "roll", 0.0)
        orig_distance = camera.distance

        doc_data = self.app.document_data({}) or {}
        if not isinstance(doc_data, dict):
            doc_data = {}

        plant_scenes = doc_data.get("plant_scenes", {})

        created_count = 0
        overwritten_count = 0

        for lv in levels:
            level_name = lv["name"]
            level_z = float(lv["z"])

            plant_name = f"Planta {level_name}"
            cut_z = level_z + 1.50

            existing_view = next(
                (v for v in scene.saved_views if v.name == plant_name),
                None
            )

            if existing_view:
                reply = QMessageBox.question(
                    self,
                    _t("Levels"),
                    f"La escena '{plant_name}' ya existe.\n"
                    f"¿Deseas sobreescribirla con corte a +{cut_z:.2f} m?",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.No
                )

                if reply == QMessageBox.No:
                    continue

                # Eliminar el plano de corte anterior
                if existing_view.section:
                    old_uid = existing_view.section.get("active")

                    if old_uid is not None:
                        scene.section_planes[:] = [
                            p for p in scene.section_planes
                            if p.uid != old_uid
                        ]

                scene.saved_views.remove(existing_view)
                overwritten_count += 1

            # Crear el plano de corte
            section = SectionPlane(
                point=QVector3D(0.0, 0.0, cut_z),
                normal=QVector3D(0.0, 0.0, 1.0),
                name=f"Corte {plant_name}",
                symbol="",
                active=True,
            )
            scene.section_planes.append(section)
            scene.set_active_section(section)

            # Configurar la cámara para la vista de planta
            camera.set_view("top")
            camera.perspective = False
            camera.target = QVector3D(
                camera.target.x(),
                camera.target.y(),
                cut_z
            )

            # Mostrar el corte y ocultar el indicador del plano
            scene.show_section_planes = False
            scene.show_section_cuts = True

            # Guardar la escena
            new_view = SavedView.capture(
                plant_name,
                scene,
                camera
            )
            scene.saved_views.append(new_view)

            plant_scenes[level_name] = {
                "scene": plant_name,
                "level_z": level_z,
                "cut_z": cut_z,
                "section_uid": section.uid,
            }
            created_count += 1

        # Restaurar la cámara original
        camera.perspective = orig_perspective
        camera.target = orig_target
        camera.yaw = orig_yaw
        camera.pitch = orig_pitch

        if hasattr(camera, "roll"):
            camera.roll = orig_roll

        camera.distance = orig_distance

        # Guardar referencias
        doc_data["plant_scenes"] = plant_scenes
        self.app.set_document_data(doc_data)

        scene.version += 1
        self.app.viewport.update()

        # Actualizar el panel Escenas
        tray = getattr(self.app, "tray", None)
        if tray is not None:
            scenes = getattr(tray, "scenes", None)
            if scenes is not None:
                scenes.refresh()

        msg = f"Escenas creadas: {created_count}"
        if overwritten_count:
            msg += f"\nEscenas sobreescritas: {overwritten_count}"

        QMessageBox.information(
            self,
            _t("Levels"),
            msg + "\n\nLas plantas están disponibles en el panel de Escenas."
        )

    def refresh(self) -> None:
        st = _state(self.app)
        self.guides.blockSignals(True)
        self.guides.setChecked(st["guides"])
        self.guides.blockSignals(False)
        current = self.list.currentRow()
        self.list.clear()
        for lv in reversed(st["levels"]):          # the highest on top
            self.list.addItem(QListWidgetItem(f"{lv['name']}   {_fmt(lv['z'])} m"))
        if 0 <= current < self.list.count():
            self.list.setCurrentRow(current)

    def _index(self):
        """The selected level's index in the height-sorted list."""
        row = self.list.currentRow()
        n = len(_state(self.app)["levels"])
        return None if row < 0 or row >= n else n - 1 - row

    def _store(self, st: dict) -> None:
        self.app.set_document_data(st)             # one undo step
        self.refresh()

    def _on_guides(self, on: bool) -> None:
        st = _state(self.app)
        st["guides"] = bool(on)
        self._store(st)

    def _add(self) -> None:
        st = _state(self.app)
        top = max((lv["z"] for lv in st["levels"]), default=-2.6)
        dlg = _LevelDialog(self, _t("New level"),
                           _t("Level {n}", n=len(st["levels"]) + 1), top + 2.6)
        if dlg.exec() != QDialog.Accepted or not dlg.name.text().strip():
            return
        st["levels"].append({"name": dlg.name.text().strip(),
                             "z": dlg.z.value()})
        self._store(st)

    def _edit(self) -> None:
        i = self._index()
        if i is None:
            return
        st = _state(self.app)
        lv = st["levels"][i]
        dlg = _LevelDialog(self, _t("Edit level"), lv["name"], lv["z"])
        if dlg.exec() != QDialog.Accepted or not dlg.name.text().strip():
            return
        lv["name"], lv["z"] = dlg.name.text().strip(), dlg.z.value()
        self._store(st)

    def _delete(self) -> None:
        i = self._index()
        if i is None:
            return
        st = _state(self.app)
        del st["levels"][i]
        self._store(st)


# ---- Viewport: guides and snapping ------------------------------------------------

def _guide_ends(viewport, z: float):
    """Two world points of a horizontal line at height `z running across
    the view, through the model — or None when the view is not sideways."""
    cam = viewport.camera
    right = QVector3D(-math.sin(cam.yaw), math.cos(cam.yaw), 0.0)
    c = cam.target
    span = max(cam.distance * 10.0, 100.0)
    return (QVector3D(c.x(), c.y(), z) - right * span,
            QVector3D(c.x(), c.y(), z) + right * span)


def draw_guides(app, viewport, painter) -> None:
    st = _state(app)
    if not st["guides"] or not st["levels"] or not _sideways(viewport):
        return
    color = QColor.fromRgbF(*COLOR, 0.9)
    pen = QPen(color, 1.2, Qt.DashLine)
    font = QFont()
    font.setPointSize(9)
    painter.setFont(font)
    for lv in st["levels"]:
        a, b = _guide_ends(viewport, lv["z"])
        pa, pb = viewport._world_to_pixel(a), viewport._world_to_pixel(b)
        if pa is None or pb is None:
            continue
        seg = viewport._clip_pixel_line(pa, pb, margin=0.0)
        if seg is None:
            continue
        (x0, y0), (x1, y1) = seg
        painter.setPen(pen)
        painter.drawLine(QPointF(x0, y0), QPointF(x1, y1))
        left = (x0, y0) if x0 <= x1 else (x1, y1)
        painter.setPen(QPen(color))
        painter.drawText(QPointF(left[0] + 8, left[1] - 4),
                         f"{lv['name']}  {_fmt(lv['z'])}")


def snap_to_levels(app, viewport, snap, px: float, py: float):
    st = _state(app)
    if not st["guides"] or not st["levels"] or not _sideways(viewport):
        return None
    p = snap.point
    here = viewport._world_to_pixel(p)
    if here is None:
        return None
    best, best_d = None, viewport.snap_threshold_px * 1.5
    for lv in st["levels"]:
        q = QVector3D(p.x(), p.y(), lv["z"])
        there = viewport._world_to_pixel(q)
        if there is None:
            continue
        d = abs(there[1] - here[1])
        if d <= best_d:
            best, best_d = (q, lv), d
    if best is None:
        return None
    from core.snap import SnapResult
    q, lv = best
    return SnapResult(q, "reference", COLOR, label=lv["name"])


# ---- Entry point --------------------------------------------------------------------

def setup(app) -> None:
    panel = LevelsPanel(app)
    app.add_panel(_t("Levels"), panel)
    app.on_document_changed(panel.refresh)
    app.add_overlay(lambda vp, painter: draw_guides(app, vp, painter))
    app.add_snap_provider(
        lambda vp, snap, px, py: snap_to_levels(app, vp, snap, px, py))
