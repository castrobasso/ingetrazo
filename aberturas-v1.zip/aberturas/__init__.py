# SPDX-License-Identifier: GPL-3.0-or-later
"""Aberturas parametricas: catalog panel and click-to-place workflow."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPainter, QPen, QPixmap, QVector3D
from PySide6.QtWidgets import (QComboBox, QDoubleSpinBox, QFormLayout,
                               QLabel, QListWidget, QListWidgetItem,
                               QPushButton, QVBoxLayout, QWidget)

from core.i18n import tr
from core.history import Command
from tools.place_group import PlaceGroupTool

from .geometry import construir_abertura, crear_cortante, es_abertura

# Data-driven catalog. Thumbnail paths are stable extension resource paths;
# a generated icon is used until custom preview images are supplied.
ABERTURAS = [
    {"id":"puerta_simple", "nombre":"Puerta Simple", "categoria":"Puertas", "thumbnail":"resources/door.svg", "ancho":90, "alto":210, "hojas":1},
    {"id":"puerta_corrediza_2", "nombre":"Puerta Corrediza 2 Hojas", "categoria":"Puertas", "thumbnail":"resources/sliding-door.svg", "ancho":160, "alto":210, "hojas":2},
    {"id":"ventana_corrediza_2", "nombre":"Ventana Corrediza 2 Hojas", "categoria":"Ventanas", "thumbnail":"resources/sliding-window.svg", "ancho":120, "alto":120, "hojas":2},
    {"id":"ventana_batiente_2", "nombre":"Ventana Batiente 2 Hojas", "categoria":"Ventanas", "thumbnail":"resources/casement-window.svg", "ancho":120, "alto":120, "hojas":2},
    {"id":"ventana_corrediza_3", "nombre":"Ventana Corrediza 3 Hojas", "categoria":"Ventanas", "thumbnail":"resources/three-window.svg", "ancho":180, "alto":120, "hojas":3},
    {"id":"ventana_corrediza_4", "nombre":"Ventana Corrediza 4 Hojas", "categoria":"Ventanas", "thumbnail":"resources/four-window.svg", "ancho":200, "alto":120, "hojas":4},
]


def _icon(thumbnail=None):
    if thumbnail:
        image = QPixmap(str(thumbnail))
        if not image.isNull():
            return image.scaled(48, 48, Qt.KeepAspectRatio,
                                Qt.SmoothTransformation)
    pix = QPixmap(48, 48)
    pix.fill(Qt.transparent)
    p = QPainter(pix)
    p.setPen(QPen(QColor("#56616b"), 3))
    p.drawRect(11, 5, 26, 38)
    p.setPen(QPen(QColor("#77b9d4"), 2))
    p.drawLine(24, 7, 24, 41)
    p.end()
    return pix


class AberturasPanel(QWidget):
    def __init__(self, app):
        super().__init__(app.window)
        self.app = app
        self.catalog = {a["id"]: a for a in ABERTURAS}
        layout = QVBoxLayout(self)
        self.category = QComboBox()
        self.category.addItems(["Todas", "Puertas", "Ventanas"])
        layout.addWidget(self.category)
        self.items = QListWidget()
        layout.addWidget(self.items, 1)
        form = QFormLayout()
        self.width = QDoubleSpinBox(); self.width.setRange(1, 2000); self.width.setDecimals(1); self.width.setSuffix(" cm")
        self.height = QDoubleSpinBox(); self.height.setRange(1, 2000); self.height.setDecimals(1); self.height.setSuffix(" cm")
        form.addRow("Ancho", self.width)
        form.addRow("Alto", self.height)
        layout.addLayout(form)
        self.place = QPushButton("Insertar abertura")
        layout.addWidget(self.place)
        self.cut = QPushButton("Abrir hueco en muro")
        self.cut.setToolTip("Selecciona la abertura y un muro sólido cerrado")
        layout.addWidget(self.cut)
        self.category.currentTextChanged.connect(self._populate)
        self.items.currentItemChanged.connect(self._select)
        self.place.clicked.connect(self._place)
        self.cut.clicked.connect(self._cut_wall)
        self._populate()

    def _populate(self, category="Todas"):
        self.items.clear()
        for entry in ABERTURAS:
            if category != "Todas" and entry["categoria"] != category:
                continue
            path = Path(__file__).parent / entry["thumbnail"]
            # Accept common raster alternatives even though the catalog's
            # default path ends in SVG; artists can supply PNG/JPEG/WebP.
            candidates = [path, *(path.with_suffix(ext) for ext in
                          (".png", ".jpg", ".jpeg", ".webp"))]
            thumbnail = next((p for p in candidates if p.is_file()), None)
            item = QListWidgetItem(_icon(thumbnail), entry["nombre"])
            item.setData(Qt.UserRole, entry["id"])
            item.setToolTip(str(thumbnail or path))
            self.items.addItem(item)
        if self.items.count():
            self.items.setCurrentRow(0)

    def _select(self, item, _old=None):
        if item is None:
            return
        cfg = self.catalog[item.data(Qt.UserRole)]
        self.width.setValue(cfg["ancho"])
        self.height.setValue(cfg["alto"])

    def _place(self):
        item = self.items.currentItem()
        if item is None:
            return
        cfg = self.catalog[item.data(Qt.UserRole)]
        group = construir_abertura(cfg, self.width.value(), self.height.value())
        self.app.viewport.set_active_tool(PlaceGroupTool(group, align_to_face=True))
        self.app.viewport.flash_status("Haz clic en el modelo para colocar la abertura")

    def _cut_wall(self):
        from core.group import Group
        from core.history import CompoundCommand, InsertGroupCommand
        from core import solids

        from core.mesh import Face

        scene = self.app.scene
        selected = [g for g in scene.selection if isinstance(g, Group)]
        faces = [f for f in scene.selection if isinstance(f, Face)]
        if faces and len(selected) == 1 and es_abertura(selected[0]):
            # A face of a wall that was never grouped: the solid it belongs
            # to becomes a group and takes the hole, in one undo step.
            self._cut_loose_wall(selected[0], faces)
            return
        if len(selected) != 2:
            self.app.viewport.flash_status(
                "Selecciona la abertura y el muro, o una cara del muro "
                "(Mayús para sumar el segundo)", 5000)
            return
        openings = [g for g in selected if es_abertura(g)]
        if len(openings) != 1:
            self.app.viewport.flash_status(
                "La selección debe incluir una abertura colocada", 4000)
            return
        opening = openings[0]
        wall = selected[0] if selected[1] is opening else selected[1]
        if wall is opening or not solids.is_solid(wall):
            self.app.viewport.flash_status(
                "El muro debe ser un grupo sólido cerrado", 5000)
            return
        try:
            cutter = crear_cortante(opening)
            cut = solids.SolidOperationCommand(solids.SUBTRACT,
                                               [cutter, wall])
            cut.prepare()
            command = CompoundCommand([InsertGroupCommand(cutter), cut])
            self.app.viewport.history.execute(command)
        except ModuleNotFoundError as exc:
            if exc.name == "manifold3d":
                self.app.viewport.flash_status(
                    "Falta manifold3d, que usan las herramientas de sólidos "
                    "de IngeTrazo", 7000)
                return
            raise
        except (solids.SolidError, ValueError) as exc:
            self.app.viewport.flash_status(str(exc), 5000)
            return
        # The cut wall keeps its name instead of the generic "Difference".
        for result in (cut.created or []):
            result.name = wall.name
        self.app.viewport.flash_status(
            f"Hueco abierto en «{wall.name}»", 3500)
        self.app.viewport.update()

    def _cut_loose_wall(self, opening, faces):
        from core import solids
        from core.group import Group

        scene = self.app.scene
        if scene.edit_group is not None:
            self.app.viewport.flash_status(
                "Sal del grupo (Esc) para abrir el hueco en una cara suelta",
                5000)
            return
        wall_faces, wall_edges = _connected_solid(faces)
        # Try the cut on a throwaway copy first: the real command must not
        # fail half-way (and IngeTrazo 0.5.7 has no clean way to refuse).
        trial = Group(_copy_faces(wall_faces), "Muro")
        if not solids.is_solid(trial):
            self.app.viewport.flash_status(
                "La cara no pertenece a un muro sólido cerrado", 5000)
            return
        try:
            solids.SolidOperationCommand(
                solids.SUBTRACT, [crear_cortante(opening), trial]).prepare()
        except ModuleNotFoundError as exc:
            if exc.name == "manifold3d":
                self.app.viewport.flash_status(
                    "Falta manifold3d, que usan las herramientas de sólidos "
                    "de IngeTrazo", 7000)
                return
            raise
        except (solids.SolidError, ValueError) as exc:
            self.app.viewport.flash_status(str(exc), 5000)
            return
        self.app.viewport.history.execute(
            _GroupAndCut(wall_faces, wall_edges, opening))
        self.app.viewport.flash_status(
            "Muro agrupado y hueco abierto (Ctrl+Z deshace las dos cosas)",
            4000)
        self.app.viewport.update()


def _connected_solid(faces):
    """Every loose face joined by edges to ``faces``, and their edges —
    the whole wall a single picked face belongs to."""
    seen = set(faces)
    todo = list(faces)
    edges = set()
    while todo:
        face = todo.pop()
        for loop in (face.loop, *face.hole_loops):
            for v in loop:
                for e in v.edges:
                    if face not in e.faces:
                        continue
                    edges.add(e)
                    for other in e.faces:
                        if other not in seen:
                            seen.add(other)
                            todo.append(other)
    return list(seen), list(edges)


def _copy_faces(faces):
    from core.mesh import Mesh
    mesh = Mesh()
    for f in faces:
        mesh.add_face([QVector3D(v) for v in f.vertices],
                      [[QVector3D(v) for v in h] for h in f.holes] or None)
    return mesh


class _GroupAndCut(Command):
    """Make Group over a loose wall, then subtract the opening's cutter
    from it — one undo step."""

    def __init__(self, faces, edges, opening):
        from core.history import MakeGroupCommand
        self._make = MakeGroupCommand(faces, edges, name="Muro")
        self._opening = opening
        self._insert = None
        self._cut = None

    def do(self, scene):
        from core import solids
        from core.history import InsertGroupCommand

        self._make.do(scene)
        wall = self._make.group
        cutter = crear_cortante(self._opening)
        cut = solids.SolidOperationCommand(solids.SUBTRACT, [cutter, wall])
        try:
            cut.prepare()           # checked on a copy before; never expected
        except Exception:
            self._make.undo(scene)
            raise
        self._insert = InsertGroupCommand(cutter)
        self._insert.do(scene)
        cut.do(scene)
        self._cut = cut
        for result in (cut.created or []):
            result.name = wall.name

    def undo(self, scene):
        self._cut.undo(scene)
        self._insert.undo(scene)
        self._make.undo(scene)


def setup(app):
    """Register the Aberturas side panel through the public extension API."""
    app.add_panel("Aberturas", AberturasPanel(app))
