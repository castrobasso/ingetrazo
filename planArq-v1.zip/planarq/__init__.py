# SPDX-License-Identifier: GPL-3.0-or-later
"""Construcción — muros, tuberías y perfiles siguiendo un eje editable.

Los nodos y parámetros son la definición del elemento; la malla del grupo se
regenera desde ellos. Los perfiles se leen del catálogo JSON junto al plugin.

Autoría: José Castro Basso, arquitecto, docente de FADU–UDELAR.
Sitio web: https://www.vinche.com
"""
from __future__ import annotations

import math
import json
from pathlib import Path

from PySide6.QtCore import Qt, QRectF
from PySide6.QtGui import QColor, QPen, QPixmap, QVector3D
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDoubleSpinBox, QFormLayout, QGroupBox,
    QHBoxLayout, QLabel, QPushButton, QScrollArea, QToolButton,
    QVBoxLayout, QWidget,
)

from core.group import Group
from core.history import Command
from core.mesh import Mesh
from core.sweep import sweep_preview_faces, sweep_profile
from tools.base import Tool, ToolContext


COLORS = {
    "Celeste": (0.20, 0.72, 0.88), "Azul": (0.12, 0.30, 0.82),
    "Amarillo": (0.96, 0.78, 0.12), "Naranja": (0.94, 0.39, 0.10),
    "Terracota": (0.69, 0.30, 0.21), "Marrón": (0.38, 0.23, 0.14),
    "Blanco": (0.94, 0.94, 0.91), "Rojo": (0.82, 0.12, 0.12),
    "Verde": (0.17, 0.57, 0.28), "Gris claro": (0.72, 0.74, 0.75),
    "Gris oscuro": (0.27, 0.29, 0.31), "Plata": (0.67, 0.72, 0.76),
    "Cobre": (0.72, 0.40, 0.22),
}
SIDES = ("Interior (izquierda del recorrido)", "Centro",
         "Exterior (derecha del recorrido)")
PROFILE_LABELS = {
    "IPN": "Acero IPN", "IPE": "Acero IPE", "UPN": "Acero UPN",
    "Tubo_Rectangular": "Tubo rectangular", "Tubo_Circular": "Tubo circular",
    "Steel_Framing_PGC": "Steel framing PGC",
    "escuadrias_madera": "Escuadría de madera",
}
PROFILE_STEEL_COLOR = (0.55, 0.61, 0.66)
PROFILE_WOOD_COLOR = (0.66, 0.43, 0.24)


def _load_profile_catalog():
    path = Path(__file__).with_name("perfiles.json")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


PROFILE_CATALOG = _load_profile_catalog()


def _profile_families():
    families = PROFILE_CATALOG.get("perfiles_acero", {})
    rows = list(families.items()) if isinstance(families, dict) else []
    wood = PROFILE_CATALOG.get("escuadrias_madera")
    if isinstance(wood, dict):
        rows.append(("escuadrias_madera", wood))
    return rows


def _family_data(key):
    if key == "escuadrias_madera":
        return PROFILE_CATALOG.get(key, {})
    return PROFILE_CATALOG.get("perfiles_acero", {}).get(key, {})


def _element_label(record):
    if record.get("type") == "wall":
        return "Muro"
    if record.get("type") == "pipe":
        return "Tubería"
    return "Perfil"


def _copy(value):
    import json
    return json.loads(json.dumps(value))


def _store(scene, key, records):
    data = scene.plugin_data.setdefault(key, {})
    data["elements"] = _copy(records)


def _records(scene, key):
    return (getattr(scene, "plugin_data", {}).get(key, {}) or {}).get(
        "elements", {})


def _frame(nodes):
    tangent = (nodes[1] - nodes[0]).normalized()
    up = QVector3D(0, 0, 1)
    side = QVector3D.crossProduct(up, tangent)
    if side.length() < 1e-8:
        side = QVector3D(1, 0, 0)
    else:
        side.normalize()
    return side, up


def _pipe_frame(nodes):
    tangent = (nodes[1] - nodes[0]).normalized()
    ref = QVector3D(0, 0, 1)
    if abs(QVector3D.dotProduct(tangent, ref)) > 0.95:
        ref = QVector3D(0, 1, 0)
    side = QVector3D.crossProduct(tangent, ref).normalized()
    up = QVector3D.crossProduct(side, tangent).normalized()
    return side, up


def _profile_section(record, center, side, up):
    """Build an editable catalogue section, using JSON dimensions in mm."""
    spec = record.get("profile_data") or {}
    shape = spec.get("tipo_forma")
    dims = spec.get("dimensions", {})
    mm = 0.001
    angle = math.radians(float(record.get("rotation", 0.0)))
    cos_a, sin_a = math.cos(angle), math.sin(angle)

    def point(x, y):
        x, y = x * mm, y * mm
        rx, ry = x * cos_a - y * sin_a, x * sin_a + y * cos_a
        return center + side * rx + up * ry

    def required(name):
        value = float(dims.get(name, 0.0))
        if value <= 0:
            raise ValueError(f"El perfil requiere una dimensión {name} positiva")
        return value

    loops = []
    if shape in ("I_SHAPE", "U_SHAPE", "C_SHAPE"):
        h, b, t = required("H"), required("B"), required("tw" if shape != "C_SHAPE" else "t")
        if shape == "I_SHAPE":
            tf = required("tf")
            if 2 * tf >= h or t >= b:
                raise ValueError("Las alas y el alma no caben en este perfil")
            pts = [(-b/2,-h/2),(b/2,-h/2),(b/2,-h/2+tf),(t/2,-h/2+tf),
                   (t/2,h/2-tf),(b/2,h/2-tf),(b/2,h/2),(-b/2,h/2),
                   (-b/2,h/2-tf),(-t/2,h/2-tf),(-t/2,-h/2+tf),
                   (-b/2,-h/2+tf)]
        elif shape == "U_SHAPE":
            tf = required("tf")
            if 2 * tf >= h or t >= b:
                raise ValueError("Las alas y el alma no caben en este perfil")
            pts = [(-b/2,-h/2),(b/2,-h/2),(b/2,-h/2+tf),
                   (-b/2+t,-h/2+tf),(-b/2+t,h/2-tf),
                   (b/2,h/2-tf),(b/2,h/2),(-b/2,h/2)]
        else:
            lip = float(dims.get("c", 0.0))
            if t >= min(h, b) or lip <= 0 or 2 * lip >= h:
                raise ValueError("Las dimensiones del canal C no son válidas")
            pts = [(-b/2,-h/2),(b/2,-h/2),(b/2,-h/2+lip),
                   (b/2-t,-h/2+lip),(b/2-t,-h/2+t),(-b/2+t,-h/2+t),
                   (-b/2+t,h/2-t),(b/2-t,h/2-t),(b/2-t,h/2-lip),
                   (b/2,h/2-lip),(b/2,h/2),(-b/2,h/2)]
        loops.append([point(x, y) for x, y in pts])
    elif shape == "RECT_TUBE":
        h, b, t = required("H"), required("B"), required("t")
        if 2 * t >= min(h, b):
            raise ValueError("El espesor no cabe en el tubo rectangular")
        loops = [
            [point(-b/2,-h/2), point(b/2,-h/2), point(b/2,h/2), point(-b/2,h/2)],
            [point(-b/2+t,-h/2+t), point(-b/2+t,h/2-t),
             point(b/2-t,h/2-t), point(b/2-t,-h/2+t)],
        ]
    elif shape == "CIRC_TUBE":
        d, t = required("D"), required("t")
        if 2 * t >= d:
            raise ValueError("El espesor no cabe en el tubo circular")
        n = 32
        loops = [[point((d/2)*math.cos(2*math.pi*i/n),
                        (d/2)*math.sin(2*math.pi*i/n)) for i in range(n)],
                 [point(((d/2-t)*math.cos(2*math.pi*i/n)),
                        ((d/2-t)*math.sin(2*math.pi*i/n)))
                  for i in reversed(range(n))]]
    elif shape == "RECT_SOLID":
        h, b = required("H"), required("B")
        loops.append([point(-b/2,-h/2), point(b/2,-h/2),
                      point(b/2,h/2), point(-b/2,h/2)])
    else:
        raise ValueError(f"Tipo de sección no reconocido: {shape}")
    profile_mesh = Mesh()
    face = profile_mesh.add_face(loops[0], loops[1:])
    return face


def _profile(record, nodes):
    if len(nodes) < 2:
        raise ValueError("El eje necesita al menos dos nodos")
    for a, b in zip(nodes, nodes[1:]):
        if (b - a).length() < 1e-7:
            raise ValueError("Hay dos nodos consecutivos coincidentes")
    side, up = (_pipe_frame(nodes) if record["type"] in ("pipe", "profile")
                else _frame(nodes))
    profile_mesh = Mesh()
    profile_type = record["type"]
    if profile_type == "profile":
        rgb = (PROFILE_WOOD_COLOR if record.get("profile_data", {}).get("family")
               == "escuadrias_madera" else PROFILE_STEEL_COLOR)
    else:
        color_name = record.get("color", "Gris claro" if profile_type == "wall"
                                 else "Celeste")
        rgb = COLORS.get(color_name, COLORS["Celeste"])
    attrs = {"color": rgb}
    if profile_type == "pipe":
        radius = float(record["diameter"]) / 2.0
        if radius <= 0:
            raise ValueError("El diámetro debe ser mayor que cero")
        inner = max(0.0, radius - float(record.get("wall", 0.04)))
        if inner <= 0:
            inner = radius * 0.72
        center = nodes[0]
        n = 20
        outer_loop = [center + side * (radius * math.cos(2*math.pi*i/n))
                      + up * (radius * math.sin(2*math.pi*i/n))
                      for i in range(n)]
        inner_loop = [center + side * (inner * math.cos(2*math.pi*i/n))
                      + up * (inner * math.sin(2*math.pi*i/n))
                      for i in range(n)]
        inner_loop.reverse()
        face = profile_mesh.add_face(outer_loop, [inner_loop])
    elif profile_type == "wall":
        if any(math.hypot((b-a).x(), (b-a).y()) < 1e-7
               for a, b in zip(nodes, nodes[1:])):
            raise ValueError("El eje del muro debe avanzar en planta")
        width, height = float(record["width"]), float(record["height"])
        if width <= 0 or height <= 0:
            raise ValueError("El ancho y el alto deben ser mayores que cero")
        align = record.get("alignment", 1)
        lo, hi = ((0.0, width) if align == 0 else
                  (-width / 2.0, width / 2.0) if align == 1 else
                  (-width, 0.0))
        center = nodes[0]
        base = center + side * lo
        top = center + side * hi
        face = profile_mesh.add_face([
            base, top, top + up * height, base + up * height])
    else:
        face = _profile_section(record, nodes[0], side, up)
    face.attrs.update(attrs)
    return face, rgb


def _build(group, record):
    nodes = [QVector3D(*p) for p in record["nodes"]]
    face, rgb = _profile(record, nodes)
    mesh = Mesh()
    if not sweep_profile(mesh, face, nodes, False):
        raise ValueError("No se pudo generar el elemento; revisa los quiebres del eje")
    for generated in mesh.faces:
        generated.attrs["color"] = rgb
    group.mesh = mesh
    group.material = None
    if record["type"] == "wall":
        group.ifc = {"class": "IfcWall", "name": group.name}
    elif record["type"] == "pipe":
        length = sum((b - a).length() for a, b in zip(nodes, nodes[1:]))
        diameter = float(record["diameter"])
        color = record.get("color", "Celeste")
        group.ifc = {
            "class": "IfcPipeSegment",
            "name": f"{color} · Ø{diameter * 1000:g} mm",
            "path_length": length,
            "diameter": diameter,
            "color": color,
        }
    else:
        length = sum((b - a).length() for a, b in zip(nodes, nodes[1:]))
        spec = record.get("profile_data", {})
        family = spec.get("family", "")
        material = "Madera" if family == "escuadrias_madera" else "Acero"
        group.ifc = {
            "class": "IfcMember",
            "name": f"{spec.get('name', 'Perfil')} · {material.lower()}",
            "path_length": length,
            "profile_family": family,
            "profile_name": spec.get("name", "Perfil"),
            "profile_shape": spec.get("tipo_forma", ""),
            "profile_dimensions": _copy(spec.get("dimensions", {})),
            "profile_rotation": float(record.get("rotation", 0.0)),
            "material": material,
        }


class _Create(Command):
    def __init__(self, key, group, record):
        self.key, self.group, self.record = key, group, _copy(record)
        self.before_records = None

    def do(self, scene):
        if self.before_records is None:
            self.before_records = _copy(_records(scene, self.key))
        _build(self.group, self.record)
        if self.group not in scene.groups:
            scene.groups.append(self.group)
        values = _copy(self.before_records)
        values[self.group.uid] = self.record
        _store(scene, self.key, values)
        scene.selection.clear()
        scene.selection.add(self.group)
        scene.version += 1

    def undo(self, scene):
        if self.group in scene.groups:
            scene.groups.remove(self.group)
        scene.selection.discard(self.group)
        _store(scene, self.key, self.before_records)
        scene.version += 1


class _Rebuild(Command):
    def __init__(self, key, group, before, after):
        self.key, self.group = key, group
        self.before, self.after = _copy(before), _copy(after)
        self.mesh_before = self.mesh_after = None
        self.ifc_before = self.ifc_after = None

    def do(self, scene):
        if self.mesh_after is None:
            self.mesh_before = self.group.mesh.capture_state()
            self.ifc_before = _copy(self.group.ifc)
            _build(self.group, self.after)
            self.mesh_after = self.group.mesh.capture_state()
            self.ifc_after = _copy(self.group.ifc)
        else:
            self.group.mesh.restore_state(self.mesh_after)
            self.group.ifc = _copy(self.ifc_after)
        values = _copy(_records(scene, self.key))
        values[self.group.uid] = self.after
        _store(scene, self.key, values)
        scene.version += 1

    def undo(self, scene):
        self.group.mesh.restore_state(self.mesh_before)
        self.group.ifc = _copy(self.ifc_before)
        values = _copy(_records(scene, self.key))
        values[self.group.uid] = self.before
        _store(scene, self.key, values)
        scene.version += 1


class _BatchParameters(Command):
    """Apply panel parameters to selected parametric groups as one undo step."""
    def __init__(self, key, changes):
        self.key = key
        self.changes = [(g, _copy(before), _copy(after))
                        for g, before, after in changes]
        self.meshes_before = self.meshes_after = None
        self.ifc_before = self.ifc_after = None

    def do(self, scene):
        if self.meshes_after is None:
            self.meshes_before = [g.mesh for g, _, _ in self.changes]
            self.ifc_before = [_copy(g.ifc) for g, _, _ in self.changes]
            try:
                for group, _, after in self.changes:
                    _build(group, after)
            except Exception:
                for (group, _, _), mesh, ifc in zip(
                        self.changes, self.meshes_before, self.ifc_before):
                    group.mesh = mesh
                    group.ifc = ifc
                raise
            self.meshes_after = [g.mesh for g, _, _ in self.changes]
            self.ifc_after = [_copy(g.ifc) for g, _, _ in self.changes]
        else:
            for (group, _, _), mesh, ifc in zip(
                    self.changes, self.meshes_after, self.ifc_after):
                group.mesh = mesh
                group.ifc = _copy(ifc)
        records = _copy(_records(scene, self.key))
        for group, _, after in self.changes:
            records[group.uid] = after
        _store(scene, self.key, records)
        scene.version += 1

    def undo(self, scene):
        for (group, before, _), mesh, ifc in zip(
                self.changes, self.meshes_before, self.ifc_before):
            group.mesh = mesh
            group.ifc = _copy(ifc)
        records = _copy(_records(scene, self.key))
        for group, before, _ in self.changes:
            records[group.uid] = before
        _store(scene, self.key, records)
        scene.version += 1

class ConstructionTool(Tool):
    name = "Construcción"
    extension_only = True
    box_select = False
    shortcut = None
    icon = None
    vcb_label = None
    plane_lock = None
    work_plane = None
    magnetic_axis_deg = 3.0
    screen_axis_px = 9.0

    def __init__(self, app, mode="draw"):
        self.app = app
        self.mode = mode
        self.record = None
        self.nodes = []
        self.hover = None
        self.group = None
        self.selected_node = None
        self.selected_nodes = set()
        self.dragging = False
        self.preview_node = None
        self.preview_positions = {}
        self.drag_origins = {}
        self.move_pending = False
        self.pointer_moved = False
        self.drag_start_screen = None
        self.extend_end = None
        self.extension_nodes = []
        self._measurement_angle = 0.0
        self.perpendicular_mode = False
        self._through_last_xy = None
        self._through_last_ids = ()
        self._through_index = -1

    @property
    def uses_snap(self):
        return self.mode != "pick_through"

    def start_pick_through(self):
        self.mode, self.record, self.group, self.nodes = "pick_through", None, None, []
        self.work_plane = None
        self._through_last_xy = None
        self._through_last_ids = ()
        self._through_index = -1
        self.app.viewport.set_active_tool(self.app._pick_handle)

    @property
    def start_point(self):
        if self.mode == "extend" and self.extension_nodes:
            return self.extension_nodes[-1]
        if self.mode == "draw" and self.nodes:
            return self.nodes[-1]
        if self.mode == "edit" and self.move_pending and self.selected_node is not None:
            return self.nodes[self.selected_node]
        return None

    @property
    def chain_first_point(self):
        return self.start_point

    @staticmethod
    def _view_plane_normal(viewport):
        """Use exact world-axis normals in standard elevations and plan."""
        forward = QVector3D(viewport.camera.forward())
        if forward.length() < 1e-8:
            return QVector3D(0, 0, 1)
        forward.normalize()
        components = (abs(forward.x()), abs(forward.y()), abs(forward.z()))
        axis = max(range(3), key=components.__getitem__)
        if components[axis] >= 0.9962:   # within about five degrees of a standard view
            sign = (1.0 if (forward.x(), forward.y(), forward.z())[axis] >= 0
                    else -1.0)
            if axis == 0:
                return QVector3D(sign, 0, 0)
            if axis == 1:
                return QVector3D(0, sign, 0)
            return QVector3D(0, 0, sign)
        return forward

    @staticmethod
    def _project_to_plane(point, plane_point, plane_normal):
        point = QVector3D(point)
        normal = QVector3D(plane_normal)
        if normal.length() < 1e-8:
            return point
        normal.normalize()
        return point - normal * QVector3D.dotProduct(point - plane_point, normal)

    def drag_plane(self, viewport):
        if self.mode == "pick_through":
            lo, hi = viewport.scene.bounds()
            center = ((lo + hi) * 0.5 if lo is not None
                      else QVector3D(0, 0, 0))
            return center, QVector3D(viewport.camera.forward())
        if self.mode == "extend" and self.extension_nodes:
            # Continue from the actual end node in the current view plane.
            # This lets an elevation extend vertically at its existing depth;
            # a horizontal plan naturally keeps the node's Z unchanged.
            return (QVector3D(self.extension_nodes[-1]),
                    self._view_plane_normal(viewport))
        if self.mode == "edit" and self.nodes:
            # _build_ctx needs a valid world hit even for the click that
            # selects a handle. At a front/side elevation the viewport's
            # default ground plane is parallel to the cursor ray, so use a
            # camera plane from the outset; once a node is armed, anchor it
            # through that node.
            index = (self.selected_node if self.move_pending
                     and self.selected_node is not None else 0)
            return (QVector3D(self.nodes[index]),
                    self._view_plane_normal(viewport))
        return None

    def _edit_plane_point(self, viewport, point):
        """Keep the edited node on the camera-aligned plane through itself.

        Snap may return a nearby vertex from a different depth; project that
        result back onto the active elevation/plan plane before previewing or
        committing it.
        """
        if self.mode != "edit" or self.selected_node is None:
            return QVector3D(point)
        origin = self.nodes[self.selected_node]
        return self._project_to_plane(
            point, origin, self._view_plane_normal(viewport))

    def _constrain_path_point(self, viewport, point):
        if self.mode == "extend" and self.extension_nodes:
            return self._project_to_plane(
                point, self.extension_nodes[-1],
                self._view_plane_normal(viewport))
        if (self.mode == "draw" and self.perpendicular_mode
                and self.work_plane is not None):
            return self._project_to_plane(point, *self.work_plane)
        return QVector3D(point)

    def value_label(self):
        if self.mode not in ("draw", "extend") or self.hover is None:
            if self.mode == "edit" and self.move_pending and self.preview_node is not None:
                origin = self.nodes[self.selected_node]
                delta = self.preview_node - origin
                d = delta.length()
                angle = self._measurement_angle
                return (f"Desplazamiento {d:.3f} m · {angle:.1f}°", (origin + self.preview_node) * 0.5)
            return None
        origin = self.start_point
        if origin is None:
            return None
        delta = self.hover - origin
        d = delta.length()
        angle = self._measurement_angle
        return (f"{d:.3f} m · {angle:.1f}°", (origin + self.hover) * 0.5)

    def start_draw(self, record):
        self.mode, self.record, self.nodes = "draw", _copy(record), []
        self.perpendicular_mode = False
        self.group = None
        level = float(self.record.get("level", 0.0))
        self.work_plane = ((QVector3D(0, 0, level), QVector3D(0, 0, 1))
                           if self.record.get("fixed_level", True) else None)
        self.app.viewport.set_active_tool(self.app._draw_handle)

    def start_edit(self, group):
        self.mode, self.group = "edit", group
        self.record = _copy(_records(self.app.scene, self.app.key)[group.uid])
        self.nodes = [QVector3D(*p) for p in self.record["nodes"]]
        self.record.setdefault("level", self.nodes[0].z() if self.nodes else 0.0)
        self.record.setdefault("fixed_level", False)
        self.selected_node = None
        self.selected_nodes = set()
        self.dragging = self.move_pending = self.pointer_moved = False
        self.preview_node = None
        self.preview_positions = {}
        self.drag_origins = {}
        self.work_plane = None
        self.app.viewport.set_active_tool(self.app._edit_handle)

    def on_activate(self, viewport):
        if self.mode == "pick_through":
            viewport.flash_status("Selección a través: repite el clic para recorrer los elementos bajo el cursor; Esc termina")
        elif self.mode == "edit":
            viewport.flash_status("Construcción: Mayús+clic selecciona nodos; arrastra para mover. Doble clic en tramo inserta; Supr elimina")
        else:
            viewport.flash_status("Construcción: clic para marcar nodos; Enter o doble clic para terminar")
        viewport.update()

    def on_deactivate(self, viewport):
        self.hover = None
        self.dragging = self.move_pending = self.pointer_moved = False
        self.drag_start_screen = None
        self.work_plane = None
        viewport.update()

    def on_release(self, viewport):
        if self.mode != "edit" or not self.move_pending:
            return
        if self.pointer_moved and self.selected_node is not None:
            if self.preview_positions:
                for index, point in self.preview_positions.items():
                    self.nodes[index] = QVector3D(point)
                self._commit_edit(viewport)
            self.dragging = self.move_pending = self.pointer_moved = False
            self.drag_start_screen = None
        else:
            # Keep the node armed for the click–move–click alternative.
            self.dragging = False

    def on_value(self, viewport, value):
        return False

    def on_triple_click(self, ctx):
        self.on_click(ctx)

    def on_hover(self, ctx: ToolContext):
        point = QVector3D(ctx.world)
        if self.mode in ("draw", "extend"):
            point = self._constrain_path_point(ctx.viewport, point)
        if (self.mode == "draw" and self.nodes
                and self.record.get("fixed_level", True)
                and not self.perpendicular_mode):
            point.setZ(float(self.record.get("level", 0.0)))
        self.hover = point
        origin = self.start_point
        if origin is not None:
            delta = point - origin
            right = QVector3D.crossProduct(ctx.viewport.camera.forward(),
                                           ctx.viewport.camera.up_vector())
            if right.length() > 1e-8:
                right.normalize()
                up = ctx.viewport.camera.up_vector()
                self._measurement_angle = math.degrees(math.atan2(
                    QVector3D.dotProduct(delta, up),
                    QVector3D.dotProduct(delta, right)))
        if self.mode == "edit" and self.move_pending and self.selected_node is not None:
            self.preview_node = self._edit_plane_point(ctx.viewport, ctx.world)
            self._set_preview_positions(self.preview_node)
            if self.dragging and self.drag_start_screen is not None:
                self.pointer_moved |= (
                    (ctx.screen - self.drag_start_screen).manhattanLength() >= 4)
        ctx.viewport.update()

    def _node_screen(self, viewport, p):
        import numpy as np
        x, y, ok = viewport._project_px(np.asarray([[p.x(), p.y(), p.z()]]))
        return (float(x[0]), float(y[0])) if bool(ok[0]) else None

    def _nearest_node(self, viewport, x, y):
        hits = []
        for i, p in enumerate(self.nodes):
            q = self._node_screen(viewport, p)
            if q:
                d = math.hypot(q[0]-x, q[1]-y)
                if d <= 12:
                    hits.append((d, i))
        return min(hits)[1] if hits else None

    def _arm_node_move(self, index, screen):
        self.selected_node = index
        self.move_pending = True
        self.dragging = True
        self.pointer_moved = False
        self.drag_start_screen = screen
        self.preview_node = QVector3D(self.nodes[index])
        self.drag_origins = {i: QVector3D(self.nodes[i])
                             for i in self.selected_nodes}
        self._set_preview_positions(self.preview_node)

    def _set_preview_positions(self, target):
        if self.selected_node is None:
            self.preview_positions = {}
            return
        anchor = self.drag_origins.get(self.selected_node,
                                       self.nodes[self.selected_node])
        delta = QVector3D(target) - anchor
        self.preview_positions = {
            i: self.drag_origins.get(i, QVector3D(self.nodes[i])) + delta
            for i in self.selected_nodes
        }

    def on_click(self, ctx: ToolContext):
        if self.mode == "pick_through":
            self._pick_through(ctx)
            return
        if self.mode in ("draw", "extend"):
            p = self._constrain_path_point(ctx.viewport, ctx.world)
            if (self.mode == "draw"
                    and (not self.nodes or self.record.get("fixed_level", True))
                    and not self.perpendicular_mode):
                p.setZ(float(self.record.get("level", 0.0)))
            if self.mode == "extend":
                if not self.extension_nodes or (p-self.extension_nodes[-1]).length() > 1e-6:
                    self.extension_nodes.append(p)
            elif not self.nodes or (p-self.nodes[-1]).length() > 1e-6:
                self.nodes.append(p)
            if len(self.nodes) == 1:
                ctx.viewport.flash_status(
                    "Inicio marcado: mueve el cursor y haz clic en el extremo; "
                    "Enter termina el recorrido")
            else:
                ctx.viewport.flash_status(
                    f"Eje: {len(self.nodes)} nodos. Añade quiebres y termina "
                    "con Enter o doble clic")
            ctx.viewport.update()
            return
        x, y = ctx.screen.x(), ctx.screen.y()
        shift = bool(ctx.modifiers & Qt.ShiftModifier)
        if shift:
            hit = self._nearest_node(ctx.viewport, x, y)
            if hit is not None:
                if hit in self.selected_nodes:
                    self.selected_nodes.remove(hit)
                    if self.selected_node == hit:
                        self.selected_node = (next(iter(self.selected_nodes))
                                              if self.selected_nodes else None)
                    self.move_pending = False
                    self.dragging = False
                    self.preview_positions = {}
                else:
                    self.selected_nodes.add(hit)
                    self._arm_node_move(hit, ctx.screen)
                ctx.viewport.flash_status(
                    f"{len(self.selected_nodes)} nodo(s) seleccionado(s); Mayús+clic para agregar o quitar")
                ctx.viewport.update()
                return
        if self.move_pending and self.selected_node is not None:
            pressed_node = self._nearest_node(ctx.viewport, x, y)
            if pressed_node in self.selected_nodes:
                # After multi-select, a fresh press on any highlighted handle
                # starts the group drag; a click elsewhere remains the
                # click–move–click destination gesture.
                self._arm_node_move(pressed_node, ctx.screen)
                ctx.viewport.update()
                return
            target = self._edit_plane_point(ctx.viewport, ctx.world)
            self._set_preview_positions(target)
            if any((self.preview_positions[i] - self.nodes[i]).length() > 1e-6
                   for i in self.preview_positions):
                for index, point in self.preview_positions.items():
                    self.nodes[index] = QVector3D(point)
                self._commit_edit(ctx.viewport)
            self.dragging = self.move_pending = self.pointer_moved = False
            self.drag_start_screen = None
            return
        i = self._nearest_node(ctx.viewport, x, y)
        if i is not None:
            self.selected_nodes = {i}
            self._arm_node_move(i, ctx.screen)
            ctx.viewport.flash_status(
                "Arrastra el nodo y suelta para moverlo; también puedes "
                "hacer clic en el destino. Doble clic en un tramo inserta; Supr elimina")
        ctx.viewport.update()

    def on_double_click(self, ctx: ToolContext):
        if self.mode == "pick_through":
            self._pick_through(ctx)
            return
        if self.mode == "extend":
            point = self._constrain_path_point(ctx.viewport, ctx.world)
            if (point - self.extension_nodes[-1]).length() > 1e-6:
                self.extension_nodes.append(point)
            self._finish_extension(ctx.viewport)
            return
        if self.mode == "draw":
            # Qt replaces the second press of a double click with this event;
            # include that position as the final axis node before finishing.
            point = self._constrain_path_point(ctx.viewport, ctx.world)
            if ((not self.nodes or self.record.get("fixed_level", True))
                    and not self.perpendicular_mode):
                point.setZ(float(self.record.get("level", 0.0)))
            if not self.nodes or (point - self.nodes[-1]).length() > 1e-6:
                self.nodes.append(point)
            self._finish(ctx.viewport)
            return
        if self.mode == "edit":
            self.move_pending = self.dragging = self.pointer_moved = False
            self.selected_node = None
            self.selected_nodes = set()
            endpoint = self._nearest_node(ctx.viewport, ctx.screen.x(), ctx.screen.y())
            if endpoint in (0, len(self.nodes) - 1) and len(self.nodes) >= 2:
                self.extend_end = "start" if endpoint == 0 else "end"
                self.extension_nodes = [QVector3D(self.nodes[endpoint])]
                self.mode = "extend"
                self.work_plane = None
                ctx.viewport.flash_status("Extensión: marca nuevos tramos desde el extremo y termina con Enter o doble clic")
                ctx.viewport.update()
                return
            hit = self._segment_hit(ctx.viewport, ctx.screen.x(), ctx.screen.y())
            if hit is not None and len(self.nodes) < 100:
                i, t = hit
                point = self.nodes[i] * (1.0 - t) + self.nodes[i + 1] * t
                self.nodes.insert(i + 1, point)
                self._commit_edit(ctx.viewport)

    def _nearest_segment(self, viewport, x, y):
        hit = self._segment_hit(viewport, x, y)
        return hit[0] if hit else None

    def _segment_hit(self, viewport, x, y):
        best = (12.0, None)
        for i, (a, b) in enumerate(zip(self.nodes, self.nodes[1:])):
            pa, pb = self._node_screen(viewport, a), self._node_screen(viewport, b)
            if not pa or not pb:
                continue
            dx, dy = pb[0]-pa[0], pb[1]-pa[1]
            den = dx*dx+dy*dy
            t = 0 if den == 0 else max(0, min(1, ((x-pa[0])*dx+(y-pa[1])*dy)/den))
            d = math.hypot(x-(pa[0]+t*dx), y-(pa[1]+t*dy))
            if d < best[0]:
                best = d, (i, t)
        return best[1]

    def _finish(self, viewport):
        if len(self.nodes) < 2:
            viewport.flash_status("El eje necesita al menos dos nodos")
            return
        record = _copy(self.record)
        record["nodes"] = [[p.x(), p.y(), p.z()] for p in self.nodes]
        if record["type"] == "profile":
            group_name = record.get("profile_data", {}).get("name", "Perfil")
        else:
            group_name = _element_label(record)
        group = Group(name=group_name)
        try:
            viewport.history.execute(_Create(self.app.key, group, record))
        except Exception as exc:
            viewport.flash_status(f"Construcción: {exc}", 5000)
            return
        if viewport.history.last_error:
            viewport.flash_status(f"Construcción: {viewport.history.last_error}", 5000)
            return
        viewport.notify_scene_changed()
        viewport.update()
        self.nodes = []

    def _finish_extension(self, viewport):
        if len(self.extension_nodes) < 2:
            viewport.flash_status("Marca al menos un nodo nuevo para extender el eje")
            return
        additions = self.extension_nodes[1:]
        all_nodes = (list(reversed(additions)) + self.nodes if self.extend_end == "start"
                     else self.nodes + additions)
        before, after = _copy(self.record), _copy(self.record)
        if self.extend_end == "start" and after["type"] == "wall":
            # Prepending nodes reverses the path's traversal direction; swap
            # the side selector to keep the existing wall on the same side.
            after["alignment"] = 2 - int(after.get("alignment", 1))
        after["nodes"] = [[p.x(), p.y(), p.z()] for p in all_nodes]
        try:
            viewport.history.execute(_Rebuild(self.app.key, self.group, before, after))
        except Exception as exc:
            viewport.flash_status(f"Construcción: {exc}", 5000)
            return
        self.nodes = all_nodes
        self.record = after
        self.mode = "edit"
        self.extension_nodes = []
        self.extend_end = None
        viewport.notify_scene_changed()
        viewport.flash_status("Eje extendido")
        viewport.update()

    def _commit_edit(self, viewport):
        if len(self.nodes) < 2:
            viewport.flash_status("El eje necesita al menos dos nodos")
            return
        before = _copy(self.record)
        after = _copy(before)
        after["nodes"] = [[p.x(), p.y(), p.z()] for p in self.nodes]
        if after["nodes"] == before["nodes"]:
            return
        try:
            viewport.history.execute(_Rebuild(self.app.key, self.group, before, after))
        except Exception as exc:
            self.nodes = [QVector3D(*p) for p in before["nodes"]]
            viewport.flash_status(f"Construcción: {exc}", 5000)
            return
        if viewport.history.last_error:
            self.nodes = [QVector3D(*p) for p in before["nodes"]]
            viewport.flash_status(f"Construcción: {viewport.history.last_error}", 5000)
            return
        self.record = after
        viewport.notify_scene_changed()
        viewport.update()

    def on_key(self, viewport, key, modifiers):
        if self.mode == "pick_through" and key == Qt.Key_Escape:
            self.app._window._activate_tool("select")
            return True
        if (key == Qt.Key_Z and self.mode == "draw" and self.record
                and self.record.get("type") in ("pipe", "profile")):
            self.perpendicular_mode = not self.perpendicular_mode
            level = float(self.record.get("level", 0.0))
            origin = (QVector3D(self.nodes[-1]) if self.nodes else
                      QVector3D(0, 0, level))
            if self.perpendicular_mode:
                forward = QVector3D(viewport.camera.forward())
                normal = QVector3D(forward.x(), forward.y(), 0.0)
                if normal.length() < 1e-6:
                    normal = QVector3D(0, 1, 0)
                normal.normalize()
                self.work_plane = (origin, normal)
                viewport.flash_status(f"{_element_label(self.record)}: plano vertical perpendicular a la vista (Z para volver al horizontal)")
            else:
                self.work_plane = (origin, QVector3D(0, 0, 1))
                viewport.flash_status(f"{_element_label(self.record)}: plano horizontal (Z para pasar al vertical)")
            refresh = getattr(viewport, "_refresh_snap", None)
            if refresh is not None:
                refresh()
            viewport.update()
            return True
        if self.mode == "extend" and key in (Qt.Key_Return, Qt.Key_Enter):
            self._finish_extension(viewport)
            return True
        if self.mode == "draw" and key in (Qt.Key_Return, Qt.Key_Enter):
            self._finish(viewport)
            return True
        if self.mode == "edit" and key in (Qt.Key_Delete, Qt.Key_Backspace):
            if not self.selected_nodes and self.selected_node is not None:
                self.selected_nodes = {self.selected_node}
            if not self.selected_nodes:
                return True
            if len(self.nodes) - len(self.selected_nodes) < 2:
                viewport.flash_status("Un eje paramétrico necesita al menos dos nodos")
                return True
            for index in sorted(self.selected_nodes, reverse=True):
                self.nodes.pop(index)
            self.selected_node = None
            self.selected_nodes = set()
            self.drag_origins = {}
            self.preview_positions = {}
            self._commit_edit(viewport)
            return True
        return False

    def claims_key(self, key, modifiers):
        return (key == Qt.Key_Z and self.mode == "draw" and self.record
                and self.record.get("type") in ("pipe", "profile"))

    def _pick_through(self, ctx):
        """Cycle construction groups intersected by the cursor ray, through occluders."""
        viewport = ctx.viewport
        records = _records(self.app.scene, self.app.key)
        groups = {g.uid: g for g in self.app.scene.groups
                  if isinstance(g, Group) and g.uid in records
                  and self.app.scene.entity_selectable(g)}
        if not groups:
            viewport.flash_status("No hay elementos paramétricos seleccionables")
            return
        try:
            import numpy as np
            origin, direction = viewport._pixel_to_ray(ctx.screen.x(), ctx.screen.y())
            idx = viewport._pick_index()
            face_t = viewport._hover_face_t(idx, origin, direction)
            depth_by_uid = {}
            if face_t is not None:
                for i, depth in enumerate(face_t):
                    if not np.isfinite(depth):
                        continue
                    entry = idx.entities[i]
                    owner = entry[1] if isinstance(entry, tuple) else None
                    uid = getattr(owner, "uid", None)
                    if uid in groups:
                        depth_by_uid[uid] = min(depth_by_uid.get(uid, float("inf")),
                                                float(depth))
            hits = [groups[uid] for uid, _depth in
                    sorted(depth_by_uid.items(), key=lambda item: item[1])]
        except Exception as exc:
            viewport.flash_status(f"No se pudo recorrer la selección: {exc}", 5000)
            return
        if not hits:
            viewport.flash_status("No hay un elemento paramétrico bajo el cursor")
            return
        x, y = ctx.screen.x(), ctx.screen.y()
        ids = tuple(g.uid for g in hits)
        same_spot = (self._through_last_xy is not None
                     and math.hypot(x-self._through_last_xy[0],
                                    y-self._through_last_xy[1]) <= 8
                     and ids == self._through_last_ids)
        self._through_index = ((self._through_index + 1) % len(hits)
                               if same_spot else 0)
        self._through_last_xy, self._through_last_ids = (x, y), ids
        group = hits[self._through_index]
        self.app.scene.select([group], mode="replace")
        viewport.update()
        label = _element_label(records[group.uid])
        viewport.flash_status(
            f"{label} seleccionado ({self._through_index + 1}/{len(hits)}); "
            "repite el clic en el mismo punto para recorrer los que están detrás")

    @property
    def wireframe_color(self):
        """Color the active orthogonal axis distinctly from the free preview."""
        if (self.mode in ("draw", "extend") and self.record
                and self.record.get("type") in ("pipe", "profile")):
            snap = getattr(self.app.viewport, "last_snap", None)
            if (snap is not None and snap.axis in ("x", "y", "z")
                    and snap.kind in ("axis", "axis_inference", "on_axis")):
                r, g, b = snap.color
                # Lift saturated axis colors so they remain unmistakable in a
                # perspective-parallel view over both light and dark models.
                return (min(1.0, r * 0.72 + 0.28),
                        min(1.0, g * 0.72 + 0.28),
                        min(1.0, b * 0.72 + 0.28), 1.0)
        return (0.10, 0.68, 0.82, 1.0)

    def on_cancel(self, viewport):
        if self.mode == "draw":
            self.nodes = []
        elif self.mode == "extend":
            self.mode = "edit"
            self.extension_nodes = []
            self.extend_end = None
        self.dragging = self.move_pending = self.pointer_moved = False
        self.drag_start_screen = None
        self.preview_node = None
        viewport.update()

    def rubber_band_lines(self):
        pts = list(self.nodes)
        if self.mode == "edit" and self.move_pending and self.selected_node is not None and self.preview_node is not None:
            for index, point in self.preview_positions.items():
                pts[index] = point
        elif self.mode == "extend" and self.extension_nodes:
            pts = self.extension_nodes
            if self.hover is not None:
                return list(zip(pts, pts[1:])) + [(pts[-1], self.hover)]
        elif self.mode == "draw" and self.hover is not None and pts:
            return list(zip(pts, pts[1:])) + [(pts[-1], self.hover)]
        return list(zip(pts, pts[1:]))

    def preview_faces(self):
        if self.mode not in ("draw", "extend") or not self.nodes or self.hover is None:
            return []
        path = ([QVector3D(p) for p in self.extension_nodes]
                if self.mode == "extend" else [QVector3D(p) for p in self.nodes])
        if (self.hover - path[-1]).length() < 1e-6:
            return []
        path.append(QVector3D(self.hover))
        try:
            face, _rgb = _profile(self.record, path)
            return sweep_preview_faces(face, path, False)
        except (KeyError, TypeError, ValueError):
            return []

    def draw_overlay(self, viewport, painter):
        if viewport.active_tool is not self:
            return
        if (self.mode in ("draw", "extend") and self.record
                and self.record.get("type") in ("pipe", "profile")):
            snap = getattr(viewport, "last_snap", None)
            if (snap is not None and snap.axis in ("x", "y", "z")
                    and snap.kind in ("axis", "axis_inference", "on_axis")):
                names = {"x": "X · rojo", "y": "Y · verde", "z": "Z · azul"}
                painter.save()
                painter.setPen(Qt.NoPen)
                painter.setBrush(QColor(18, 25, 34, 225))
                painter.drawRoundedRect(QRectF(12, 50, 210, 32), 6, 6)
                painter.setPen(QColor(255, 255, 255))
                font = painter.font()
                font.setBold(True)
                font.setPointSize(10)
                painter.setFont(font)
                painter.drawText(QRectF(22, 50, 190, 32),
                                 Qt.AlignVCenter | Qt.AlignLeft,
                                 f"ORTOGONAL · EJE {names[snap.axis]}")
                painter.restore()
        if self.mode != "edit":
            return
        points = list(self.nodes)
        if self.dragging and self.preview_positions:
            for index, point in self.preview_positions.items():
                points[index] = point
        painter.save()
        for i, p in enumerate(points):
            q = self._node_screen(viewport, p)
            if q is None:
                continue
            color = QColor(255, 174, 55) if i in self.selected_nodes else QColor(25, 183, 218)
            painter.setPen(QPen(QColor(30, 45, 55), 1.4))
            painter.setBrush(color)
            painter.drawEllipse(int(q[0]-5), int(q[1]-5), 10, 10)
            painter.setPen(QPen(QColor(30, 45, 55), 1))
            painter.drawText(int(q[0]+7), int(q[1]-6), str(i+1))
        painter.restore()


class _PlanArqSection(QWidget):
    """A panel section styled like the app's collapsible tray sections."""

    def __init__(self, title, content, expanded=False):
        super().__init__()
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        self.button = QToolButton()
        self.button.setText(f"  {title}")
        self.button.setCheckable(True)
        self.button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.button.setStyleSheet(
            "QToolButton { font-weight: bold; padding: 6px 4px; border: none;"
            " border-bottom: 1px solid palette(mid); text-align: left; }"
            "QToolButton:hover { background: palette(midlight); }"
        )
        self.content = content
        self.button.setChecked(expanded)
        self.content.setVisible(expanded)
        self.button.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)
        self.button.toggled.connect(self._toggle)
        lay.addWidget(self.button)
        lay.addWidget(self.content)

    def _toggle(self, expanded):
        self.content.setVisible(expanded)
        self.button.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)


class ConstructionPanel(QWidget):
    def __init__(self, app, draw_tool, edit_tool, pick_tool):
        super().__init__()
        self.app, self.draw_tool, self.edit_tool = app, draw_tool, edit_tool
        self.pick_tool = pick_tool
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QScrollArea.NoFrame)
        content = QWidget()
        root = QVBoxLayout(content)
        root.setContentsMargins(8, 6, 8, 8)
        root.setSpacing(2)
        self.scroll.setWidget(content)
        outer.addWidget(self.scroll)

        levelbox = QWidget()
        lf = QFormLayout(levelbox)
        self.level = self._spin(-1000, 10000, 0.0, 0.10)
        self.fixed_level = QCheckBox("Mantener todo el recorrido en este nivel")
        self.fixed_level.setChecked(True)
        lf.addRow("Nivel (Z)", self.level)
        lf.addRow(self.fixed_level)
        root.addWidget(_PlanArqSection(
            "Nivel de trazado", levelbox, expanded=True))

        wall = QWidget()
        wf = QFormLayout(wall)
        self.width = self._spin(0.01, 10, 0.15, 0.01)
        self.height = self._spin(0.01, 100, 2.80, 0.10)
        self.alignment = QComboBox()
        self.alignment.addItems(SIDES)
        wf.addRow("Ancho", self.width)
        wf.addRow("Alto", self.height)
        wf.addRow("Eje respecto al muro", self.alignment)
        self.draw_wall = QPushButton("Dibujar muro")
        self.draw_wall.clicked.connect(self._wall)
        wf.addRow(self.draw_wall)
        root.addWidget(_PlanArqSection("Muro", wall, expanded=True))

        pipe = QWidget()
        pf = QFormLayout(pipe)
        self.diameter = self._spin(0.005, 10, 0.10, 0.01)
        self.color = QComboBox()
        self.color.addItems(list(COLORS))
        pf.addRow("Diámetro exterior", self.diameter)
        pf.addRow("Color", self.color)
        self.draw_pipe = QPushButton("Dibujar tubería")
        self.draw_pipe.clicked.connect(self._pipe)
        pf.addRow(self.draw_pipe)
        root.addWidget(_PlanArqSection("Tubería", pipe))

        profile_box = QWidget()
        pform = QFormLayout(profile_box)
        self.profile_family = QComboBox()
        for key, _family in _profile_families():
            self.profile_family.addItem(PROFILE_LABELS.get(key, key), key)
        self.profile_size = QComboBox()
        self.profile_rotation = QComboBox()
        self.profile_rotation.addItem("0°", 0)
        self.profile_rotation.addItem("90°", 90)
        self.profile_image = QLabel("Sección del perfil")
        self.profile_image.setAlignment(Qt.AlignCenter)
        self.profile_image.setMinimumHeight(82)
        self.profile_image.setMaximumHeight(100)
        pform.addRow("Familia", self.profile_family)
        pform.addRow("Medida", self.profile_size)
        pform.addRow("Rotación", self.profile_rotation)
        pform.addRow(self.profile_image)
        self.draw_profile = QPushButton("Dibujar perfil")
        self.draw_profile.clicked.connect(self._profile)
        pform.addRow(self.draw_profile)
        self.profile_family.currentIndexChanged.connect(
            self._profile_family_changed)
        self.profile_size.currentIndexChanged.connect(
            self._profile_image_changed)
        self._profile_family_changed(self.profile_family.currentIndex())
        root.addWidget(_PlanArqSection(
            "Perfiles desde catálogo JSON", profile_box))

        editbox = QWidget()
        el = QVBoxLayout(editbox)
        self.edit = QPushButton("Editar nodos")
        self.edit.clicked.connect(self._edit)
        el.addWidget(self.edit)
        self.pick_through = QPushButton("Seleccionar elemento detrás o dentro")
        self.pick_through.clicked.connect(self.pick_tool.start_pick_through)
        el.addWidget(self.pick_through)
        self.apply_parameters = QPushButton("Actualizar parámetros de la selección")
        self.apply_parameters.clicked.connect(self._apply_parameters)
        el.addWidget(self.apply_parameters)
        self.hint = QLabel("Mayús+clic agrega o quita nodos de la selección; arrastra uno para moverlos juntos dentro del plano del alzado. Mayús también restringe el movimiento a un eje. Doble clic en un tramo inserta un nodo; en un extremo prolonga el eje. Supr elimina los nodos seleccionados.")
        self.hint.setWordWrap(True)
        el.addWidget(self.hint)
        self.notice_row = QWidget()
        notice_layout = QHBoxLayout(self.notice_row)
        notice_layout.setContentsMargins(4, 8, 4, 2)
        notice_layout.setSpacing(4)
        self.notice = QLabel(
            "Aviso: geometrías y metrajes esquemáticos, solo para "
            "precálculo orientativo. No son cálculo estructural ni "
            "documentación de obra; verifica resultados con el profesional "
            "responsable."
        )
        self.notice.setWordWrap(True)
        self.notice.setStyleSheet("QLabel { color: #858585; font-size: 10px; }")
        self.notice.setToolTip(
            "Todo lo generado es esquemático. No verifica resistencia, cargas, "
            "uniones, normativa ni condiciones del sitio. Verifica medidas, "
            "materiales y cantidades antes de presupuestar o construir."
        )
        self.notice_close = QToolButton()
        self.notice_close.setText("×")
        self.notice_close.setToolTip("Cerrar aviso hasta la próxima vez que abras IngeTrazo")
        self.notice_close.setStyleSheet(
            "QToolButton { color: #858585; border: none; font-size: 14px; "
            "padding: 0 3px; } QToolButton:hover { color: palette(text); }"
        )
        self.notice_close.clicked.connect(self.notice_row.hide)
        notice_layout.addWidget(self.notice, 1)
        notice_layout.addWidget(self.notice_close, 0, Qt.AlignTop)
        root.addWidget(_PlanArqSection("Editar elemento seleccionado", editbox))
        root.addStretch(1)
        root.addWidget(self.notice_row)

    @staticmethod
    def _spin(lo, hi, value, step):
        w = QDoubleSpinBox()
        w.setRange(lo, hi)
        w.setDecimals(3)
        w.setSingleStep(step)
        w.setValue(value)
        w.setSuffix(" m")
        return w

    def _wall(self):
        self.draw_tool.start_draw({"type": "wall", "width": self.width.value(),
                              "height": self.height.value(),
                              "alignment": self.alignment.currentIndex(),
                              "level": self.level.value(),
                              "fixed_level": self.fixed_level.isChecked()})

    def _pipe(self):
        self.draw_tool.start_draw({"type": "pipe", "diameter": self.diameter.value(),
                              "wall": max(self.diameter.value() * 0.08, 0.003),
                              "color": self.color.currentText(),
                              "level": self.level.value(),
                              "fixed_level": self.fixed_level.isChecked()})

    def _profile_family_changed(self, _index):
        family_key = self.profile_family.currentData()
        family = _family_data(family_key) if family_key else {}
        self.profile_size.blockSignals(True)
        self.profile_size.clear()
        for name in (family.get("items", {}) or {}):
            self.profile_size.addItem(name, name)
        self.profile_size.blockSignals(False)
        self.draw_profile.setEnabled(self.profile_size.count() > 0)
        self._profile_image_changed(self.profile_size.currentIndex())

    def _profile_image_changed(self, _index):
        family = _family_data(self.profile_family.currentData())
        image_path = family.get("IMAGEN")
        pixmap = (QPixmap(str(Path(__file__).parent / image_path))
                  if image_path else QPixmap())
        if pixmap.isNull():
            self.profile_image.setPixmap(QPixmap())
            self.profile_image.setText("Vista previa no disponible")
            return
        self.profile_image.setText("")
        self.profile_image.setPixmap(pixmap.scaled(
            180, 96, Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def _profile_record(self):
        family_key = self.profile_family.currentData()
        family = _family_data(family_key)
        name = self.profile_size.currentData()
        item = (family.get("items", {}) or {}).get(name, {})
        if not item:
            raise ValueError("Elige una familia y una medida de perfil")
        return {
            "type": "profile",
            "profile_data": {
                "family": family_key,
                "name": name,
                "tipo_forma": family.get("tipo_forma", ""),
                "dimensions": _copy(item),
            },
            "rotation": float(self.profile_rotation.currentData() or 0),
            "level": self.level.value(),
            "fixed_level": self.fixed_level.isChecked(),
        }

    def _profile(self):
        try:
            record = self._profile_record()
        except ValueError as exc:
            self.app.viewport.flash_status(str(exc))
            return
        self.draw_tool.start_draw(record)

    def _edit(self):
        groups = [g for g in self.app.scene.selection
                  if isinstance(g, Group) and g.uid in _records(self.app.scene, self.app.key)]
        if not groups:
            self.app.viewport.flash_status("Selecciona uno o más elementos paramétricos")
            return
        self.edit_tool.start_edit(groups[0])

    def _apply_parameters(self):
        groups = [g for g in self.app.scene.selection
                  if isinstance(g, Group) and g.uid in _records(self.app.scene, self.app.key)]
        if not groups:
            self.app.viewport.flash_status("Selecciona uno o más elementos paramétricos")
            return
        records = _records(self.app.scene, self.app.key)
        selected_type = records[groups[0].uid]["type"]
        groups = [g for g in groups if records[g.uid]["type"] == selected_type]
        changes = []
        for group in groups:
            before = _copy(records[group.uid])
            after = _copy(before)
            if after["type"] == "wall":
                after.update(width=self.width.value(), height=self.height.value(),
                             alignment=self.alignment.currentIndex())
            elif after["type"] == "pipe":
                after.update(diameter=self.diameter.value(),
                             wall=max(self.diameter.value() * 0.08, 0.003),
                             color=self.color.currentText())
            else:
                try:
                    profile = self._profile_record()
                except ValueError as exc:
                    self.app.viewport.flash_status(str(exc))
                    return
                after.update(profile_data=profile["profile_data"],
                             rotation=profile["rotation"])
            if after != before:
                changes.append((group, before, after))
        if not changes:
            self.app.viewport.flash_status("Los parámetros ya tienen esos valores")
            return
        try:
            self.app.viewport.history.execute(_BatchParameters(self.app.key, changes))
        except Exception as exc:
            self.app.viewport.flash_status(f"Construcción: {exc}", 5000)
            return
        self.app.viewport.notify_scene_changed()
        self.app.viewport.flash_status(f"Parámetros actualizados en {len(changes)} elemento(s)")

    def load_record(self, record):
        if record["type"] == "wall":
            self.width.setValue(record.get("width", 0.15))
            self.height.setValue(record.get("height", 2.8))
            self.alignment.setCurrentIndex(record.get("alignment", 1))
        elif record["type"] == "pipe":
            self.diameter.setValue(record.get("diameter", 0.1))
            self.color.setCurrentText(record.get("color", "Celeste"))
        else:
            spec = record.get("profile_data", {})
            idx = self.profile_family.findData(spec.get("family"))
            if idx >= 0:
                self.profile_family.setCurrentIndex(idx)
                size_idx = self.profile_size.findData(spec.get("name"))
                if size_idx >= 0:
                    self.profile_size.setCurrentIndex(size_idx)
            rotation_idx = self.profile_rotation.findData(
                int(record.get("rotation", 0)))
            if rotation_idx >= 0:
                self.profile_rotation.setCurrentIndex(rotation_idx)



# IngeTrazo's extension loader builds by itself every Tool class it finds in
# the module, with no arguments; ConstructionTool needs the app and a mode,
# and setup() builds it. Marking it as living elsewhere keeps the loader
# away from it on every IngeTrazo version (0.5.7 included).
ConstructionTool.__module__ = __name__ + ".tools"

def setup(app):
    draw_tool = ConstructionTool(app, "draw")
    edit_tool = ConstructionTool(app, "edit")
    pick_tool = ConstructionTool(app, "pick_through")
    app._draw_handle = draw_tool
    app._edit_handle = edit_tool
    app._pick_handle = pick_tool
    app.add_overlay(draw_tool.draw_overlay)
    app.add_overlay(edit_tool.draw_overlay)
    panel = ConstructionPanel(app, draw_tool, edit_tool, pick_tool)
    app.add_panel("planArq", panel)

    def refresh():
        panel.update()
        selected = [g for g in app.scene.selection
                    if isinstance(g, Group) and g.uid in _records(app.scene, app.key)]
        if selected:
            panel.load_record(_records(app.scene, app.key)[selected[0].uid])
        group = edit_tool.group
        if group is not None:
            record = _records(app.scene, app.key).get(group.uid)
            if record is not None:
                edit_tool.record = _copy(record)
                edit_tool.nodes = [QVector3D(*p) for p in record["nodes"]]
                app.viewport.update()
            else:
                edit_tool.group = None
                edit_tool.nodes = []
                app.viewport.update()

    app.on_document_changed(refresh)
