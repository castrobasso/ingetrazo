# SPDX-License-Identifier: GPL-3.0-or-later
"""Parametric opening geometry, independent from the Qt interface."""
from __future__ import annotations

from PySide6.QtGui import QVector3D

from core.group import Group
from core.mesh import Mesh

CM = 0.01
FRAME_FACE = (1.0, 1.0, 1.0)
GLASS = (0.55, 0.82, 0.94)


def aplicar_materiales(group: Group, color=FRAME_FACE, opacity=1.0):
    group.material = {"color": (*color, opacity)}
    return group


def _box(name, x0, y0, z0, x1, y1, z1, color=FRAME_FACE, opacity=1.0):
    mesh = Mesh()
    pts = [(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0),
           (x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)]
    for face in ((0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)):
        mesh.add_face([QVector3D(*pts[i]) for i in face])
    group = Group(mesh, name)
    aplicar_materiales(group, color, opacity)
    return group


def crear_marco(ancho, alto, profundidad, tipo, tracks=1, umbral=True,
                corredizo=False):
    """Create an outer frame; sliding tracks run along it, never across it."""
    g = Group(name="Marco")
    rail = 0.04
    depth = profundidad
    parts = [_box("Perfil superior", 0, -depth/2, alto-rail, ancho, depth/2, alto),
             _box("Jamba izquierda", 0, -depth/2, 0, rail, depth/2, alto),
             _box("Jamba derecha", ancho-rail, -depth/2, 0, ancho, depth/2, alto)]
    if umbral:
        parts.append(_box("Umbral inferior", 0, -depth/2, 0,
                          ancho, depth/2, rail))
    # Parallel top/bottom runners provide separate sliding planes. A fixed
    # centre stile would prevent the leaves from crossing one another.
    if corredizo:
        runner = 0.008
        for track in range(tracks):
            y = -depth/2 + (track + 0.5)*depth/tracks
            parts.extend((
                _box(f"Carril inferior {track+1}",0,y-runner/2,rail-0.004,
                     ancho,y+runner/2,rail+0.004),
                _box(f"Carril superior {track+1}",0,y-runner/2,alto-rail-0.004,
                     ancho,y+runner/2,alto-rail+0.004),
            ))
    g.adopt(parts)
    return g


def crear_hoja(ancho, alto, y, solape=False, vidriada=True, abatible=False):
    """One independently grouped leaf with profiles and optional glass."""
    g = Group(name="Hoja")
    d = 0.05
    profile = 0.035
    parts = [_box("Perfil superior",0,y-d/2,alto-profile,ancho,y+d/2,alto),
             _box("Perfil inferior",0,y-d/2,0,ancho,y+d/2,profile),
             _box("Perfil izquierdo",0,y-d/2,0,profile,y+d/2,alto),
             _box("Perfil derecho",ancho-profile,y-d/2,0,ancho,y+d/2,alto)]
    if vidriada:
        glass = _box("Vidrio",profile,y-0.002,profile,ancho-profile,y+0.002,alto-profile,GLASS,0.35)
        glass.material["mat"] = "Vidrio translúcido"
        glass.name = "Vidrio"
        parts.append(glass)
    else:
        parts.append(_box("Panel macizo",profile,y-d/2,profile,ancho-profile,y+d/2,alto-profile))
    g.adopt(parts)
    if solape:
        g.name = "Hoja con solape"
    if abatible:
        g.name = "Hoja pivotante"
    return g


def construir_abertura(config: dict, ancho_cm: float, alto_cm: float) -> Group:
    """Build the nested root/Marco/Hojas tree for one catalog configuration."""
    w, h = float(ancho_cm)*CM, float(alto_cm)*CM
    if w <= 0 or h <= 0:
        raise ValueError("Ancho y alto deben ser mayores que cero")
    kind = config["id"]
    root = Group(name=config["nombre"])
    track_count = (3 if kind == "ventana_corrediza_3" else
                   2 if kind in {"ventana_corrediza_2", "ventana_corrediza_4"}
                   else 1)
    depth = max(0.08, 0.05 * track_count)
    is_door = kind.startswith("puerta")
    frame = crear_marco(w, h, depth, kind, tracks=track_count,
                        umbral=not is_door, corredizo="corrediza" in kind)
    count = config["hojas"]
    leaves = Group(name="Hojas")
    clear_w = w - 0.08
    stile_overlap = (0.035 if count > 1 and "corrediza" in kind
                     and kind != "puerta_corrediza_2" else 0.0)
    # Each leaf spans its share of the clear opening plus one stile width;
    # adjacent leaves consequently overlap at the meeting line.
    leaf_w = clear_w / count + stile_overlap
    slide = "corrediza" in kind
    hinged = "batiente" in kind
    solid = kind.startswith("puerta")
    leaves_list = []
    for i in range(count):
        track_y = (-depth/2 + ((i % track_count) + 0.5)*depth/track_count
                   if slide else (-0.012 if i % 2 else 0.012))
        sill_offset = 0.0 if is_door else 0.04
        leaf = crear_hoja(leaf_w, h-0.04-sill_offset, track_y,
                          solape=slide and count == 2, vidriada=not solid,
                          abatible=hinged)
        leaf.name = f"Hoja {i+1}"
        # Per-leaf placement across the opening, inset from the jambs.
        from PySide6.QtGui import QMatrix4x4
        m = QMatrix4x4()
        m.translate(0.04 + i*clear_w/count, 0, sill_offset)
        leaf.xform = m
        leaves_list.append(leaf)
    leaves.adopt(leaves_list)
    root.adopt([frame, leaves])
    return root


def es_abertura(group: Group) -> bool:
    """Recognize a placed opening from its persistent group hierarchy."""
    names = {getattr(child, "name", "") for child in
             (getattr(group, "children", None) or [])}
    return "Marco" in names and "Hojas" in names


def crear_cortante(abertura: Group) -> Group:
    """Build a through-wall prism in the opening's local frame.

    Its opening bounds come from the frame itself, so this still works after
    saving and reopening the model; the temporary cutter is never retained.
    """
    from PySide6.QtGui import QMatrix4x4
    from core.group import placement_points

    marco = next((child for child in abertura.children
                  if getattr(child, "name", "") == "Marco"), None)
    if marco is None:
        raise ValueError("No se encontró el marco de la abertura")
    points = placement_points(marco)
    if not len(points):
        raise ValueError("El marco no contiene geometría")
    lo, hi = points.min(axis=0), points.max(axis=0)
    # The wall opening follows the exterior frame dimensions, leaving room
    # for the complete frame to sit inside the cut.
    x0, x1 = float(lo[0]), float(hi[0])
    z0, z1 = float(lo[2]), float(hi[2])
    # Ten metres spans ordinary architectural wall thicknesses while the
    # rectangle remains limited to the clear width and height of the frame.
    cutter = _box("Cortante temporal (abertura)", x0, -5.0, z0,
                  x1, 5.0, z1)
    if abertura.xform is not None:
        cutter.xform = QMatrix4x4(abertura.xform)
    return cutter
